package me.astero.companions.filemanager;

import lombok.Getter;
import lombok.Setter;

public class PhysicalAbilitiesDetails {
	
	@Getter @Setter private int chance, duration;

}
